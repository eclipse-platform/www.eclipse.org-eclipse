package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class TraversalDemo3 extends Canvas {
	
	Color focusColor;
	Color red;
	Color blue;
	Color green;
	Rectangle rect = new Rectangle(10, 10, 100, 100);
		
TraversalDemo3(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	red = display.getSystemColor(SWT.COLOR_RED);
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	green = display.getSystemColor(SWT.COLOR_GREEN);
	focusColor = red;
	Listener listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				if (isFocusControl()) {
					e.gc.setBackground(focusColor);
					e.gc.fillRectangle(rect);
					e.gc.drawFocus(rect.x, rect.y, rect.width, rect.height);
				} else {
					e.gc.setBackground(blue);
					e.gc.fillRectangle(rect);
				}
				break;
			case SWT.FocusIn:
			case SWT.FocusOut:
				redraw(rect.x, rect.y, rect.width, rect.height, false);
				break;
			case SWT.KeyDown:
				System.out.println("Key pressed "+e.character+" "+e.keyCode);
				break;
			case SWT.Traverse:
				// Handle Escape and Return as special cases
				switch (e.detail) {
//				case SWT.TRAVERSE_RETURN:
//				case SWT.TRAVERSE_ESCAPE:
//					focusColor = e.detail == SWT.TRAVERSE_ESCAPE ? red : green;
//					e.doit = true;
//					e.detail = SWT.TRAVERSE_NONE;
//					redraw(rect.x, rect.y, rect.width, rect.height, false);
//					break;
				default:
					e.doit = true;
				}
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.FocusIn, listener);
	addListener(SWT.FocusOut, listener);
	addListener(SWT.KeyDown, listener);
	addListener(SWT.Traverse, listener);
}

static int checkStyle(int style) {
	return style;
}

public static void main (String [] args) {
	Display display = new Display ();
	final Shell shell = new Shell (display);
	shell.setText("Main window");
	shell.setLayout(new FillLayout());
	Button b = new Button(shell, SWT.PUSH);
	b.setText("Open Dialog");
	b.addListener(SWT.Selection, new Listener() {
		public void handleEvent(Event e) {
			Shell dialog = new Shell(shell, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
			dialog.setText("Dialog");
			dialog.setLayout(new FillLayout());
			Button b = new Button(dialog, SWT.PUSH);
			b.setText("Button 1");
			new TraversalDemo3(dialog, SWT.NONE);
			b = new Button(dialog, SWT.PUSH);
			b.setText("Button 2");
			dialog.setDefaultButton(b);
			b.addListener(SWT.Selection, new Listener() {
				public void handleEvent(Event e) {
					Button b = (Button)e.widget;
					b.getShell().close();
				}
			});
			dialog.setSize(600, 400);
			dialog.open ();
		}
	});
	shell.setSize(100, 100);
	shell.open();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
