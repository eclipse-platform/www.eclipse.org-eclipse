package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class SizeDemo1 extends Canvas {
	
	Image image;
	Listener listener;
	int margin = 10;
	
SizeDemo1(Composite parent, int style) {
	super(parent, checkStyle(style));
	image = new Image(getDisplay(), SizeDemo1.class.getResourceAsStream("tigger.gif"));
	listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				e.gc.drawImage(image, margin, margin);
				Rectangle bounds = image.getBounds();
				int width = bounds.width + 2*margin - 1;
				int height = bounds.height + 2*margin - 1;
				e.gc.drawRoundRectangle(0, 0, width, height, margin, margin);
				break;
			case SWT.Dispose:
				removeListener(SWT.Dispose, listener);
				notifyListeners(SWT.Dispose, e);
				e.type = SWT.None;
				image.dispose();
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
}

public Point computeSize(int wHint, int hHint, boolean changed) {
	checkWidget();
	Rectangle bounds = image.getBounds();
	Point size = new Point(bounds.width + 2*margin, bounds.height + 2*margin);
	if (wHint != SWT.DEFAULT) size.x = wHint;
	if (hHint != SWT.DEFAULT) size.y = hHint;
	return size;
}

static int checkStyle(int style) {
	return style | SWT.DOUBLE_BUFFERED;
}

public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new GridLayout(6, false));
	SizeDemo1 demo = new SizeDemo1(shell, SWT.NONE);
	demo.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 5));
	for (int i = 0; i < 20; i++) {
		Button b = new Button(shell, SWT.PUSH);
		b.setText("Button "+i);
	}
	shell.pack();
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
