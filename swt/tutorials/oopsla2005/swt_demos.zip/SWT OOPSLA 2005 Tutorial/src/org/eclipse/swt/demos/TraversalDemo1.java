package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class TraversalDemo1 extends Canvas {

	Color red;
	Color blue;
	Rectangle rect = new Rectangle(10, 10, 100, 100);
		
TraversalDemo1(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	red = display.getSystemColor(SWT.COLOR_RED);
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	Listener listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				if (isFocusControl()) {
					e.gc.setBackground(red);
					e.gc.fillRectangle(rect);
					e.gc.drawFocus(rect.x, rect.y, rect.width, rect.height);
				} else {
					e.gc.setBackground(blue);
					e.gc.fillRectangle(rect);
				}
				break;
			case SWT.FocusIn:
			case SWT.FocusOut:
				redraw(rect.x, rect.y, rect.width, rect.height, false);
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.FocusIn, listener);
	addListener(SWT.FocusOut, listener);
	// **** Add key listener to get keyboard focus
	//addListener(SWT.KeyDown, listener);
}

static int checkStyle(int style) {
	return style;
}

public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	Button b = new Button(shell, SWT.PUSH);
	b.setText("Button 1");
	new TraversalDemo1(shell, SWT.NONE);
	b = new Button(shell, SWT.PUSH);
	b.setText("Button 2");
	shell.setSize(600, 400);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
