package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class MirroringDemo2 extends Canvas{
	
	Shell shell;
	Color blue;
	Rectangle rect = new Rectangle(10, 10, 200, 200);
	
MirroringDemo2(Composite parent, int style) {
	super(parent, style);
	Display display = getDisplay();
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	addListener(SWT.Paint, new Listener() {
		public void handleEvent(Event e) {
			e.gc.setForeground(blue);
			e.gc.drawRectangle(rect);
		}
	});
	addListener(SWT.MouseEnter, new Listener() {
		public void handleEvent(Event e) {
			if (shell != null) return;
			Display display = getDisplay();
			shell = new Shell(getShell(), SWT.NO_TRIM | SWT.TOOL | SWT.ON_TOP);
			shell.setBackground(display.getSystemColor(SWT.COLOR_INFO_BACKGROUND));
			
			// BAD - translate point in top left corner
			Point pt = display.map(MirroringDemo2.this, null, rect.x, rect.y);
			shell.setBounds(pt.x, pt.y, rect.width, rect.height);
			
			// GOOD - map entire rectangle
			//Rectangle rect2 = display.map(MirroringDemo2.this, null, rect);
			//shell.setBounds(rect2);
			//shell.setVisible(true);
		}
	});
	addListener(SWT.MouseExit, new Listener() {
		public void handleEvent(Event e) {
			if (shell != null) shell.dispose();
			shell = null;
		}
	});
}
public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	int style = SWT.NONE;
	style |= SWT.RIGHT_TO_LEFT;
	Composite parent = new Composite(shell, style);
	parent.setLayout(new FillLayout());
	new MirroringDemo2(parent, SWT.NONE);
	shell.setSize(400, 400);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
