package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class PaintDemo extends Canvas {
	
	Color[] colors;
	int index;
	
static int checkStyle(int style) {
	return style;
	//return style | SWT.NO_REDRAW_RESIZE;
	//return style | SWT.NO_REDRAW_RESIZE | SWT.NO_MERGE_PAINTS;
}

public PaintDemo(Composite parent,int style) {
	super(parent,checkStyle(style));
	Display display = getDisplay();
	colors = new Color[5];
	colors[0] = display.getSystemColor(SWT.COLOR_RED);
	colors[1] = display.getSystemColor(SWT.COLOR_BLUE);
	colors[2] = display.getSystemColor(SWT.COLOR_GREEN);
	colors[3] = display.getSystemColor(SWT.COLOR_CYAN);
	colors[4] = display.getSystemColor(SWT.COLOR_MAGENTA);
	
	Listener listener = new Listener() {
		public void handleEvent(Event e){
			switch (e.type){
			case SWT.Paint:
				Rectangle area = getClientArea();
				e.gc.setBackground(colors[index]);
				e.gc.fillRectangle(area);
				index = (index + 1) % colors.length;
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
}

public static void main(String[] args) {
	Display display = new Display();
	Shell shell = new Shell(display);
	shell.setLayout(new GridLayout());
	final PaintDemo demo = new PaintDemo(shell,SWT.NONE);
	demo.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
	Button b = new Button(shell, SWT.PUSH);
	b.setText("damage");
	b.addListener(SWT.Selection, new Listener() {
		public void handleEvent(Event e) {
			demo.redraw(10, 10, 100, 100, false);
			demo.redraw(110, 110, 100, 100, false);
			demo.redraw(10, 200, 100, 100, false);
		}
	});
	shell.open();
	while (!shell.isDisposed()) {
		if (!display.readAndDispatch())
			display.sleep();
	}
	display.dispose();
}
}
