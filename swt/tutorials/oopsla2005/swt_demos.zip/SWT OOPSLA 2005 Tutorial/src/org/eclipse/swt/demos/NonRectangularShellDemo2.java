package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.widgets.*;

public class NonRectangularShellDemo2 {
	
public static void main(String[] args) {
	final Display display = new Display();
	//String animatedGif = "penguin.gif";
	//String animatedGif = "fan.gif"
	//String animatedGif = "goose.gif";
	String animatedGif = "tigger.gif";
	final ImageData[] datas = new ImageLoader().load(
			NonRectangularShellDemo2.class.getResourceAsStream(animatedGif));
	final Image[] images = new Image[datas.length];
	final Region[] regions = new Region[datas.length];
	loadImages(display, datas, images, regions);
	final Shell shell = new Shell(display, SWT.NO_TRIM | SWT.ON_TOP | SWT.NO_BACKGROUND);

	final int[] currentImage = new int[]{-1};
	Listener listener = new Listener() {
		int startX, startY;
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.MouseDown:
				startX = e.x;
				startY = e.y; 
				break;
			case SWT.MouseMove:
				if ((e.stateMask & SWT.BUTTON1) != 0) {
					Point p = shell.toDisplay(e.x, e.y);
					p.x -= startX;
					p.y -= startY;
					shell.setLocation(p);
				}
				break;
			case SWT.Paint:
				ImageData data = datas[currentImage[0]];
				e.gc.drawImage(images[currentImage[0]], data.x, data.y);
				break;
			case SWT.MouseDoubleClick:
				shell.dispose();
				break;
			}
		}
	};
	shell.addListener(SWT.MouseDoubleClick, listener);
	shell.addListener(SWT.MouseDown, listener);
	shell.addListener(SWT.MouseMove, listener);
	shell.addListener(SWT.Paint, listener);

	Runnable animate = new Runnable() {
		public void run() {
			if (shell.isDisposed()) return;
			currentImage[0] = (currentImage[0] + 1) % images.length;
			ImageData data = datas[currentImage[0]];
			Point location = shell.getLocation();
			shell.setSize(data.x + data.width, data.y + data.height);
			shell.setRegion(regions[currentImage[0]]);
			shell.redraw();
			int time = datas[currentImage[0]].delayTime * 10;
			display.timerExec(time == 0 ? 500 : visibleDelay(time), this);
		}		
	};
	animate.run();
	shell.setVisible(true);
	while (!shell.isDisposed()) {
		if (!display.readAndDispatch()) display.sleep();
	}
	for (int i = 0; i < images.length; i++) {
		regions[i].dispose();
		images[i].dispose();
	}
	display.dispose();
}

static ImageData[] loadDatas(String[] names) {
	ImageData[] datas = new ImageData[names.length];
	for (int i = 0; i < names.length; i++) {
		datas[i] = new ImageData(names[i]);
	}
	return datas;
}

static void loadImages(Display display, ImageData[] datas, Image[] images, Region[] regions) {
	for (int i = 0; i < datas.length; i++) {
		Region region = new Region(display);
		ImageData data = datas[i];
		ImageData mask = data.getTransparencyMask();
		Rectangle pixel = new Rectangle(0, 0, 1, 1);
		for (int y = 0; y < mask.height; y++) {
			for (int x = 0; x < mask.width; x++) {
				if (mask.getPixel(x, y) != 0) {
					pixel.x = data.x + x;
					pixel.y = data.y + y;
					region.add(pixel);
				}
			}
		}
		images[i] = new Image(display, datas[i]);
		regions[i] = region;
	} 
}

static int visibleDelay(int ms) {
	if (ms < 20) return ms + 30;
	if (ms < 30) return ms + 10;
	return ms;
}
}