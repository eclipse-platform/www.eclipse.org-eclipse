package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class SizeDemo2 extends Composite {
	
	int margin = 20;
	int borderTop;
	Font titleFont;
	Color red;
	String title = "Put Title Here";
	Listener listener;
	
SizeDemo2(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	titleFont = new Font(display, "Arial", 20, SWT.BOLD);
	red = display.getSystemColor(SWT.COLOR_RED);
	GC gc = new GC(this);
	gc.setFont(titleFont);
	borderTop = gc.textExtent(title).y + 2*margin;
	gc.dispose();
	listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				GC gc = e.gc;
				gc.setFont(titleFont);
				gc.drawText(title, margin, margin, true);
				gc.setForeground(red);
				Point size = getSize();
				int width = size.x - 2*margin;
				int height = size.y - borderTop - margin;
				gc.drawRectangle(margin, borderTop, width, height);
				break;
			case SWT.Dispose:
				removeListener(SWT.Dispose, listener);
				notifyListeners(SWT.Dispose, e);
				e.type = SWT.None;
				titleFont.dispose();
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.Dispose, listener);
}

// Don't need to implement computeSize because layout will handle it
//public Point computeSize(int wHint, int hHint, boolean changed) {
//}

public Rectangle computeTrim(int x, int y, int width, int height) {
	Rectangle trim = super.computeTrim(x, y, width, height);
	trim.x -= margin;
	trim.y -= borderTop;
	trim.width += 2 * margin;
	trim.height += borderTop + margin;
	return trim;
}

public Rectangle getClientArea() {
	Rectangle area = super.getClientArea();
	area.x += margin;
	area.y += borderTop;
	area.width -= 2 * margin;
	area.height -= borderTop + margin;
	return area;
}

static int checkStyle(int style) {
	return style | SWT.DOUBLE_BUFFERED;
}

public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	SizeDemo2 demo = new SizeDemo2(shell, SWT.NONE);
	demo.setLayout(new RowLayout());
	Button b = new Button(demo, SWT.PUSH);
	b.setText("Button 1");
	b = new Button(demo, SWT.PUSH);
	b.setText("Button 2");
	b = new Button(demo, SWT.PUSH);
	b.setText("Button 3");
	b = new Button(demo, SWT.PUSH);
	b.setText("Button 4");
	shell.pack();
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
