package org.eclipse.swt.demos;

import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class MnemonicDemo extends Canvas {

	String text;
	Color background;
	Font font;
	Listener listener;
	
public MnemonicDemo(Composite parent,int style) {
	super(parent,style);
	Display display = getDisplay();
	background = display.getSystemColor(SWT.COLOR_BLUE);
	FontData data = getFont().getFontData()[0];
	data.setHeight(40);
	font = new Font(display, data);
	listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				GC gc = e.gc;
				gc.setBackground(background);
				gc.fillRectangle(getClientArea());
				if (text == null) return;
				gc.setFont(font);
				gc.drawText(text, 10,10, SWT.DRAW_MNEMONIC);
				break;
			case SWT.Traverse:
				if (e.detail == SWT.TRAVERSE_MNEMONIC) {
					char mnemonic = _findMnemonic(text);
					if (mnemonic == '\0') return;
					if (Character.toUpperCase(e.character) 
							!= Character.toUpperCase(mnemonic)) return;
					background = getDisplay().getSystemColor(SWT.COLOR_RED);
					redraw();
					
				}
				break;
			case SWT.Dispose:
				removeListener(SWT.Dispose, listener);
				notifyListeners(SWT.Dispose, e);
				e.type = SWT.None;
				font.dispose();
				break;
			}
		}
	};
	addListener(SWT.Paint,listener);
	addListener(SWT.Traverse, listener);
}
public void setText(String text) {
	checkWidget();
	this.text = text;
}
char _findMnemonic (String string) {
	if (string == null) return '\0';
	int index = 0;
	int length = string.length ();
	do {
		while (index < length && string.charAt (index) != '&') index++;
		if (++index >= length) return '\0';
		if (string.charAt (index) != '&') return string.charAt (index);
		index++;
	} while (index < length);
 	return '\0';
}
public static void main(String[] args) {
	Display display = new Display();
	Shell shell = new Shell(display);
	shell.setLayout(new FillLayout());
	Button b = new Button(shell, SWT.PUSH);
	b.setText("Button");
	MnemonicDemo demo = new MnemonicDemo(shell, SWT.NONE);
	demo.setText("&Aligator");
	shell.setSize(600, 300);
	shell.open();
	while (!shell.isDisposed()) {
		if (!display.readAndDispatch())
			display.sleep();
	}
	display.dispose();
}
}
