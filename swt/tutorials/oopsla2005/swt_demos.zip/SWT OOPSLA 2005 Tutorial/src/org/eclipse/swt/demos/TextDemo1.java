package org.eclipse.swt.demos;

import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
public class TextDemo1 extends Canvas {
	
	Listener listener;
	TextLayout layout;
	Font font1, font2, font3;
	TextStyle style1, style2, style3;
	
TextDemo1(Composite parent, int style) {
	super(parent, style);
	Display display = getDisplay();
	font1 = new Font(display, "Tahoma", 14, SWT.BOLD);
	font2 = new Font(display, "MS Mincho", 20, SWT.ITALIC);
	font3 = new Font(display, "Arabic Transparent", 18, SWT.NORMAL);
	style1 = new TextStyle(font1, null, null);
	style2 = new TextStyle(font2, null, null);
	style3 = new TextStyle(font3, null, null);
	layout = new TextLayout(display);
	layout.setText("English \u65E5\u672C\u8A9E  \u0627\u0644\u0639\u0631\u0628\u064A\u0651\u0629");
	layout.setStyle(style1, 0, 6);
	layout.setStyle(style2, 8, 10);
	layout.setStyle(style3, 13, 21);
	
	listener = new Listener() {
		public void handleEvent (Event event) {
			switch (event.type) {
			case SWT.Paint:
				layout.draw(event.gc, 30, 30);
				break;
			case SWT.Dispose:
				removeListener(SWT.Dispose, listener);
				notifyListeners(SWT.Dispose, event);
				event.type = SWT.None;
				layout.dispose();
				font1.dispose();
				font2.dispose();
				font3.dispose();
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.Dispose, listener);
}
public static void main(String[] args) {
	Display display = new Display();
	Shell shell = new Shell(display);
	shell.setLayout(new FillLayout());
	new TextDemo1(shell, SWT.NONE);
	shell.setSize(300, 200);
	shell.open();
	while (!shell.isDisposed()) {
		if (!display.readAndDispatch())
			display.sleep();
	}
	display.dispose();
}
}