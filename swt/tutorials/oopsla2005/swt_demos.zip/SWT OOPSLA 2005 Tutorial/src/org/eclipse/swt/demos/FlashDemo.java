package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class FlashDemo extends Canvas{

	Color blue;
	
static int checkStyle(int style) {
	// flash
	return style;
	// no flash
	//return style | SWT.NO_REDRAW_RESIZE;
}
FlashDemo (Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	addListener(SWT.Paint, new Listener() {
		public void handleEvent(Event e) {
			GC gc = e.gc;
			gc.setBackground(blue);
			gc.fillRectangle(5, 5, 400, 400);
		}
	});
}

public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	new FlashDemo(shell, SWT.NONE);
	
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
