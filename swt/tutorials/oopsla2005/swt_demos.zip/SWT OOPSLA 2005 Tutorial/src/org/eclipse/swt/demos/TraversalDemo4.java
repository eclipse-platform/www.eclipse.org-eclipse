package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class TraversalDemo4 extends Canvas {

	Color red;
	Color blue;
	Rectangle rect = new Rectangle(10, 10, 100, 100);
		
static int checkStyle(int style) {
	return style;
	// Block mouse focus
	//return style | SWT.NO_FOCUS;
}

TraversalDemo4(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	red = display.getSystemColor(SWT.COLOR_RED);
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	Listener listener = new Listener() {
		public void handleEvent(Event e) {
			switch (e.type) {
			case SWT.Paint:
				if (isFocusControl()) {
					e.gc.setBackground(red);
					e.gc.fillRectangle(rect);
					e.gc.drawFocus(rect.x, rect.y, rect.width, rect.height);
				} else {
					e.gc.setBackground(blue);
					e.gc.fillRectangle(rect);
				}
				break;
			case SWT.FocusIn:
			case SWT.FocusOut:
				redraw(rect.x, rect.y, rect.width, rect.height, false);
				break;
			case SWT.KeyDown:
				System.out.println("Key pressed "+e.character+" "+e.keyCode);
				break;
			case SWT.Traverse:
				// Let OS traversal happen
				e.doit = true;
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.FocusIn, listener);
	addListener(SWT.FocusOut, listener);
	addListener(SWT.KeyDown, listener);
	addListener(SWT.Traverse, listener);
}

public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	Button b1 = new Button(shell, SWT.PUSH);
	b1.setText("Set Focus");
	final TraversalDemo4 demo = new TraversalDemo4(shell, SWT.NONE);
	Button b2 = new Button(shell, SWT.PUSH);
	b2.setText("Force Focus");
	b1.addListener(SWT.Selection, new Listener() {
		public void handleEvent(Event e) {
			demo.setFocus();
		}
	});
	b2.addListener(SWT.Selection, new Listener() {
		public void handleEvent(Event e) {
			demo.forceFocus();
		}
	});
	shell.setSize(600, 400);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
