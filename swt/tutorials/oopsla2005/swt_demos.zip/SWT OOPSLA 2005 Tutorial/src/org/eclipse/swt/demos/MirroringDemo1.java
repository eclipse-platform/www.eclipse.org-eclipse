package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.custom.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class MirroringDemo1 {
	
public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	int style = SWT.NONE;
	style |= SWT.RIGHT_TO_LEFT;
	SashForm parent = new SashForm(shell, style);
	Tree tree = new Tree(parent, SWT.NONE);
	for (int i = 0; i < 3; i++) {
		TreeItem item = new TreeItem(tree, SWT.NONE);
		item.setText("item "+i);
		for (int j = 0; j < 3; j++) {
			TreeItem subItem = new TreeItem(item, SWT.NONE);
			subItem.setText("item "+j);
			for (int k = 0; k < 3; k++) {
				TreeItem subsubItem = new TreeItem(subItem, SWT.NONE);
				subsubItem.setText("item "+k);
			}
		}
	}
	Text t = new Text(parent, SWT.LEAD | SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
	t.setText(string);
	shell.setSize(600, 400);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}

static String string = "Oh freddled gruntbuggly,\n"+
    "Thy micturations are to me\n"+
    "As plurdled gabbleblotchits\n"+
    "On a lurgid bee.\n"+
    "Groop, I implore thee, my foonting turlingdromes\n"+
    "And hooptiously drangle me\n"+
    "with crinkly bindlewurdles,\n"+
    "Or I will rend thee in the gobberwarts with my blurglecruncheon\n"+
    "See if I don't.";
}
