package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class CheeseDemo2 extends Canvas {
	Color red;
	Color blue;
	int oldWidth = -1;
	int oldHeight = -1;
	int borderWidth = 15;
	
static int checkStyle(int style) {
	// no flash and no cheese
	return style | SWT.NO_BACKGROUND;
}
CheeseDemo2 (Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	red = display.getSystemColor(SWT.COLOR_RED);
	blue = display.getSystemColor(SWT.COLOR_BLUE);
	addListener(SWT.Paint, new Listener() {
		public void handleEvent(Event e) {
			Canvas canvas = (Canvas)e.widget;
			Rectangle area = canvas.getClientArea();
			if ((getStyle() & SWT.NO_BACKGROUND) != 0) {
				// Tip for debugging NO_BACKGROUND
				//e.gc.setBackground(getDisplay().getSystemColor(SWT.COLOR_GREEN));
				//e.gc.fillRectangle(area);
				e.gc.setBackground(getBackground());
				e.gc.fillRectangle(0, 0, borderWidth, area.height);
				e.gc.fillRectangle(0, 0, area.width, borderWidth);
				e.gc.fillRectangle(area.width - borderWidth, 0, borderWidth, area.height);
				e.gc.fillRectangle(0, area.height - borderWidth, area.width, borderWidth);
			}
			e.gc.setBackground(blue);
			int x = borderWidth, y = borderWidth;
			int width = area.width - 2*borderWidth;
			int height = area.height - 2*borderWidth;
			e.gc.fillRectangle(x, y, width, height);
		}
	});
}
public static void main (String [] args) {
	Display display = new Display ();
	Shell shell = new Shell (display);
	shell.setLayout(new FillLayout());
	new CheeseDemo2(shell, SWT.NONE);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();
}
}
