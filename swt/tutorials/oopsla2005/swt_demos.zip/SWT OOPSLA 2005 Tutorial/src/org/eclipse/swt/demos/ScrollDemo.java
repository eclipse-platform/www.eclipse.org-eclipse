package org.eclipse.swt.demos;

import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class ScrollDemo extends Canvas {
	
	Image image;
	ScrollBar hBar;
	ScrollBar vBar;
	Point origin = new Point(0,0);
	Listener listener;
	
static int checkStyle(int style) {
	return style | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL;
}

ScrollDemo(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	image = new Image(display, ScrollDemo.class.getResourceAsStream("space.jpg"));
	origin = new Point(0,0);
	hBar = getHorizontalBar ();
	vBar = getVerticalBar ();
	hBar.addListener (SWT.Selection, new Listener () {
		public void handleEvent (Event e) {
			int hSelection = hBar.getSelection ();
			int destX = -hSelection - origin.x;
			Rectangle imageBounds = image.getBounds ();
			scroll (destX, 0, 0, 0, imageBounds.width, imageBounds.height, false);
			origin.x = -hSelection;
		}
	});
	vBar.addListener (SWT.Selection, new Listener () {
		public void handleEvent (Event e) {
			int vSelection = vBar.getSelection ();
			int destY = -vSelection - origin.y;
			Rectangle imageBounds = image.getBounds ();
			scroll (0, destY, 0, 0, imageBounds.width, imageBounds.height, false);
			origin.y = -vSelection;
		}
	});
	listener = new Listener () {
		public void handleEvent (Event e) {
			switch (e.type) {
			case SWT.Resize: {
				Rectangle rect = image.getBounds ();
				Rectangle client = getClientArea ();
				hBar.setMaximum (rect.width);
				vBar.setMaximum (rect.height);
				hBar.setThumb (Math.min (rect.width, client.width));
				vBar.setThumb (Math.min (rect.height, client.height));
				int hPage = rect.width - client.width;
				int vPage = rect.height - client.height;
				int hSelection = hBar.getSelection ();
				int vSelection = vBar.getSelection ();
				if (hSelection >= hPage) {
					if (hPage <= 0) hSelection = 0;
					origin.x = -hSelection;
				}
				if (vSelection >= vPage) {
					if (vPage <= 0) vSelection = 0;
					origin.y = -vSelection;
				}
				break;
			}
			case SWT.Paint: {
				GC gc = e.gc;
				gc.drawImage (image, origin.x, origin.y);
				break;
			}
			}
		}
	};
	addListener (SWT.Paint, listener);
	addListener (SWT.Resize, listener);
}

public static void main(String[] args) {
	Display display = new Display();
	Shell shell = new Shell(display);
	shell.setLayout(new FillLayout());
	ScrollDemo demo = new ScrollDemo(shell, SWT.NONE);
	shell.setSize (200, 150);
	shell.open ();
	while (!shell.isDisposed ()) {
		if (!display.readAndDispatch ()) display.sleep ();
	}
	display.dispose ();

}
}