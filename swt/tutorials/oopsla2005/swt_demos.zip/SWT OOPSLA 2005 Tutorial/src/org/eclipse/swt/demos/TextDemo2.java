package org.eclipse.swt.demos;
/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

public class TextDemo2 extends Canvas {
	
	int margin = 10;
	TextLayout layout;
	Listener listener;
	
TextDemo2(Composite parent, int style) {
	super(parent, checkStyle(style));
	Display display = getDisplay();
	layout = new TextLayout(display);
	layout.setText(longString);
	listener = new Listener() {
		public void handleEvent (Event event) {
			switch (event.type) {
			case SWT.Paint:
				layout.draw(event.gc, margin, margin);
				break;
			case SWT.Resize:
				layout.setWidth(getSize().x - 2*margin);
				break;
			case SWT.Dispose:
				removeListener(SWT.Dispose, listener);
				notifyListeners(SWT.Dispose, event);
				event.type = SWT.None;
				layout.dispose();
				break;
			}
		}
	};
	addListener(SWT.Paint, listener);
	addListener(SWT.Resize, listener);
	addListener(SWT.Dispose, listener);
}

static int checkStyle(int style){
	return style | SWT.DOUBLE_BUFFERED;
}

public Point computeSize(int wHint, int hHint, boolean changed) {
	checkWidget();
	int oldWidth = layout.getWidth();
	int newWidth = wHint != SWT.DEFAULT ? wHint : Integer.MAX_VALUE;
	layout.setWidth(newWidth);
	Rectangle bounds = layout.getBounds();
	layout.setWidth(oldWidth);
	Point size = new Point(bounds.width, bounds.height);
	if (wHint != SWT.DEFAULT) size.x  = wHint;
	if (hHint != SWT.DEFAULT) size.y = hHint;
	size.x += 2*margin;
	size.y += 2*margin;
	return size;
}

public static void main(String[] args) {
	Display display = new Display();
	final Shell shell = new Shell(display);
	shell.setLayout(new FillLayout());
	TextDemo2 demo = new TextDemo2(shell, SWT.NONE);
	Point size = demo.computeSize(300, SWT.DEFAULT);
	shell.setSize(shell.computeSize(size.x, size.y));
	shell.open();
	while (!shell.isDisposed()) {
		if (!display.readAndDispatch())
			display.sleep();
	}
	display.dispose();
}

final static String longString = "The preferred size of a widget is the minimum size needed to show its content. In the case of a Composite, the preferred size is the smallest rectangle that contains all of its children. If children have been positioned by the application, the Composite computes its own preferred size based on the size and position of the children. If a Composite is using a layout class to position its children, it asks the Layout to compute the size of its clientArea, and then it adds in the trim to determine its preferred size.";
}
